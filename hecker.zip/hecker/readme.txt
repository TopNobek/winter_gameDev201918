#hecker

hecker is a game made for Winter GameDev Challenge 2018/19.


#motivation

I have never written something like this before, and I thought that making this project would be a great opportunity to learn something new, 

(although I know that It was made with violation of every coding standard).


#about game

One screen contains map with a player, and the second one contains terminal imitation. Player is exploring an abandoned space station, to find

hyperdrive module. To complete it he need to demonstrate his extraordinary skills.


#how to play

(open index.html)

Your avatar is being steered with arrow keys, he can also pick up some items that are lying on the ground.

In the terminal you just simply type commands and confirms by pressing [ENTER]. On start you will receive

some hints. If word is [in brackets] it prompts you to type it.

[help] - Lists some commands.

[inv] - Lists your inventory. (To use item just type it's name to the console)

[hint] - You can always use it if you get stucked.



Some commands/items work only in special places e.g. near doors please keep that in mind during gameplay.

If you have totally no idea what to do you can check solution in file "writeups.txt", but I think that it won't be necessary.