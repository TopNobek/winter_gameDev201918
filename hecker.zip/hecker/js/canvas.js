var canvas = document.getElementById('board');
var ctx = document.getElementById('board').getContext('2d');
var width = canvas.width;
var height = canvas.height;

var ox, oy;

var playerimg = new Image();
playerimg.src = 'img/player.png';
var playerimgh = new Image();
playerimgh.src = 'img/playerh.png'

var img = [];
img.push(new Image());
img.push(new Image());
img.push(new Image());
img.push(new Image());
img.push(new Image());
img[0].src = 'img/hammer.png';
img[1].src = 'img/key.png';
img[2].src = 'img/hoodie.png';
img[3].src = 'img/paper.png';
img[4].src = 'img/module.png';

var wall = [];                                                                  // (x, y, width, height, walk, visible, color, msg)
wall.push(new collisionObject(902, 462, 100, 20));                              // 0  backdoor
wall.push(new collisionObject(612, 462, 292, 20));                              // 1  top wall stage-1
wall.push(new collisionObject(612, 650, 20, 97));                               // 2  left wall bottom
wall.push(new collisionObject(612, 462, 20, 88));                               // 3  left wall top
wall.push(new collisionObject(618, 550, 10, 100, 0, 1, '#73757a', "It looks like these doors are locked. Check your [inv] maybe you have something for it.")); // 4  doors
wall.push(new collisionObject(612, 20, 20, 442));                               // 5  left wall stage-2
wall.push(new collisionObject(20, 462, 592, 20));                               // 6  top walls stage-3
wall.push(new collisionObject(width-120, 20, 100, 100, 1, 1, '#4e6d50', "Oh, it looks like a teleportation machine! But where does it leads? Really interesting. But wait, it's secured with a fingerprint reader, is there any way to bypass it?")); // 7 teleporting machine
wall.push(new collisionObject(20, 467, 100, 10, 0, 0, '#73757a'));                                         // 8 door
wall.push(new collisionObject(20, 467, 100, 20, 1, 0, '#FFFFFF', "en13r 1h3 password"));                   // 9 msg
wall.push(new collisionObject(20, 250, 592, 20));                                                          // 10
wall.push(new collisionObject(250, 20, 20, 230, 1, 0, 'white', "It's a trap!"));                           // 11
wall.push(new collisionObject(512, 230, 100, 20, 1, 0, 'white', "none"));                                  // 12
wall.push(new collisionObject(width-120, height-120, 100, 100, 1, 1, 'white', "It's your vehicle."));      // 13
wall.push(new collisionObject(width-80, height-80, 20, 20, 1, 1, 'gray', "none"));                         // 14

var thing = [];
thing.push(new item(width-300, 500, 30, 40, 'hammer', 1, '#562909', 'You got a hammer', img[0]));
thing.push(new item(width-200, 500, 20, 40, 'key', 1, '#936d04', 'You got a key', img[1]));
thing.push(new item(width-200, 300, 50, 80, 'hoodie', 1, '#936d04', 'You got a hoodie', img[2]));
thing.push(new item(width-300, 200, 30, 40, 'white-paper', 1, '#936d04', 'You got white-paper', img[3]));
thing.push(new item(200, 250, 30, 40, 'camera', 0, '#936d04', 'You got a camera', img[2]));
thing.push(new item(50, 50, 50, 60, 'module', 0, '#936d04', 'You got a hyperdrive module', img[4]));

function keyLogger(){                                                           // CONSTRUCTORS START
  this.up = false;
  this.down = false;
  this.left = false;
  this.right = false;
}

function player(){
  this.img = playerimg;
  this.color = 'green';
  this.x = canvas.width-30;
  this.y = canvas.height-30;
  this.height = 90;
  this.width = 90;
  this.inv = ['computer'];
  this.stage = 1;
}

function collisionObject(x, y, width, height, walk, visible, color, msg){
    if(walk === undefined) {
      this.walk = 0;
    }
    else {
      this.walk = walk;
    }

    if(visible === undefined) {
      this.visible = 1;
    }
    else {
      this.visible = visible;
    }

    if(color === undefined) {
      this.color = '#202020';
    }
    else {
      this.color = color;
    }

    if(msg === undefined){
      this.msg = 'none';
    }
    else {
      this.msg = msg;
    }
    this.showed = false;
    this.x = x;
    this.y = y;
    this.width = width+30;
    this.height = height+30;

    this.collision = function(){
      if (player.x < this.x + this.width-45 &&
       player.x + player.width > this.x &&
       player.y < this.y + this.height-45 &&
       player.height + player.y > this.y) {
         if(this.msg != 'none' && this.showed == false){
           hint(this.msg);
           br();
           this.showed = true;
         }
         if(this.walk == 0) {
         return 1;
        }
        else {
          return 0;
        }
      }
      else {
        this.showed = false;
        return 0;
      }
  }
    this.draw = function(){
      if(this.visible == 1) {
      ctx.fillStyle = this.color;
      ctx.fillRect(this.x, this.y, this.width-30, this.height-30);
    }
  }
}                                                                               // CONSTRUCTORS END

function item(x, y, width, height, name, visible, color, msg, img){

    if(visible === undefined) {
      this.visible = 1;
    }
    else {
      this.visible = visible;
    }

    if(color === undefined) {
      this.color = '#202020';
    }
    else {
      this.color = color;
    }

    if(msg === undefined){
      this.msg = 'none';
    }
    else {
      this.msg = msg;
    }
    this.img = img;
    this.picked = false;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.name = name;
    this.collision = function(){
      if (player.x < this.x + this.width+30 &&
       player.x + player.width+30 > this.x &&
       player.y < this.y + this.height+30 &&
       player.height+30 + player.y > this.y) {
        if(this.picked == false){
          player.inv.push(this.name);
          hint(msg);
          br();
          this.picked = true;
          this.visible = 0;
        }
  }
}
    this.draw = function(){
      if(this.visible == 1) {
      ctx.drawImage(img, this.x, this.y, this.width, this.height);
    }
  }
}

var player = new player();
var keyLogger = new keyLogger();

document.body.addEventListener("keydown", function (e) {                        // MOVEMENT START

  let code = e.keyCode;
  if(code == 37){
    keyLogger.left = true;
  }
  else if (code == 38) {
    keyLogger.up = true;
  }
  else if (code == 39) {
    keyLogger.right = true;
  }
  else if (code == 40) {
    keyLogger.down = true;
  }
});

document.body.addEventListener("keyup", function (e) {

  let code = e.keyCode;
  if(code == 37){
    keyLogger.left = false;
  }
  else if (code == 38) {
    keyLogger.up = false;
  }
  else if (code == 39) {
    keyLogger.right = false;
  }
  else if (code == 40) {
    keyLogger.down = false;
  }
});                                                                             // MOVEMENT END
gameLoop();

function gameLoop(){                                                            // GAME LOOP START

    requestAnimationFrame(gameLoop);
    background();
    walkingRange();
    itemPicker();
    if(drawCollisions() >= 1) {
      player.x = ox;
      player.y = oy;
      drawPlayer();
    }
    else {
    ox = player.x;
    oy = player.y;
    drawPlayer();
  }
  if(wall[11].showed == true){
    wall[10].width = 622;
    wall[11].msg = 'none';
    wall[12].msg = 'It looks like a door.';
  }

  if(wall[13].showed == true && player.inv.includes('module')){
    ctx.fillStyle = '#202020';
    ctx.fillRect(0, 0, width, height);
    end();
  }

}                                                                               // GAME LOOP END

function drawPlayer(){                                                          // DRAW PLAYER START

  if(keyLogger.up){
    player.y -= 3;
  }
  else if (keyLogger.down) {
    player.y += 3;
  }
  else if (keyLogger.left) {
    player.x -= 3;
  }
  else if (keyLogger.right) {
    player.x += 3;
  }

  ctx.drawImage(player.img, player.x, player.y, player.width, player.height);
}                                                                               // DRAW PLAYER END

function background(){                                                          // MAP DRAWING START
  ctx.clearRect(0, 0, 1022, 767);

  ctx.fillStyle = '#202020';
  ctx.fillRect(0, 0, 1022, 767);
  ctx.fillStyle = '#424651';                  //  background
  ctx.fillRect(20, 20, 982, 727);

if (player.stage == 1) {
    ctx.fillStyle = '#262728';
    ctx.fillRect(20, 20, 982, 442);           //  unexplored
    ctx.fillRect(20, 20, 597, 727);
  }
  else if (player.stage == 2) {
    ctx.fillStyle = '#262728';
    ctx.fillRect(20, 20, 597, 727);           // unexplored
  }
  else if (player.stage == 3) {
    ctx.fillStyle = '#262728';
    ctx.fillRect(20, 20, 597, 447);           // unexplored
  }
  else if (player.stage == 4) {
    ctx.fillStyle = '#262728';
    ctx.fillRect(20, 20, 597, 250);           // unexplored
  }
  else if (player.stage == 5) {
    ctx.fillStyle = '#262728';
    ctx.fillRect(20, 20, 597, 250);           // unexplored
  }
}                                                                               // MAP DRAWING END

function walkingRange(){                                                        // WALKING RANGE START

    if (player.x >= 932) {               // right
      player.x = 932;
    }
   else if (player.x <= 20) {            // left
      player.x = 20;
    }
    if (player.y <= 20) {                // top
        player.y = 20;
    }
    else if (player.y >= 677) {          // bottom
        player.y = 677;
    }

}                                                                               // WALKING RANGE END


function drawCollisions(){
  let collision = 0;

for(let i = 0; i <= wall.length-1; i++){
  wall[i].draw();
  collision += wall[i].collision();
}

  switch(player.stage){
    case 1:
        wall[7].visible = 0;
      break;
    case 2:
      wall[0].walk = 1;
      wall[0].visible = 0;
      wall[7].visible = 1;
      break;
    case 3:
    if(wall[4].walk != 1){
      wall[4].walk = 1;
      wall[4].visible = 0;
      wall[4].msg = 'none';
      wall[6].x += 100;
      wall[6].width -= 100;
      wall[8].visible = 1;
    }
      break;
    case 4:
      if(wall[8].visible == 1){
          wall[8].visible = 0;
          wall[9].msg = "Wait! There is a hidden camera. You can't go there without protection.";
      }
  }

  return collision;
}

function itemPicker(){
  for(let i = 0; i < thing.length; i++){
    thing[i].draw();
    thing[i].collision();
  }

    switch(player.stage){
      case 1:
        thing[2].visible = 0;
        thing[3].visible = 0;
        break;
      case 2:
      if(thing[2].picked == false) {
        thing[2].visible = 1;
      }
      if (thing[3].picked == false) {
        thing[3].visible = 1;
      }
        break;
    }
}
