var imported = document.createElement('script');
imported.src = 'js/canvas.js';
document.head.appendChild(imported);

window.onload = function(){
  clear();
  creepyWrite("Enter your name to start...", 100);
}
var start = true;
var name;
var wait = false;

function check(element){
  if(element[0] == "echo")
  {
    element.splice(0, 1);
    var textnode = document.createTextNode(element.join(" "));
  }
  else if (element[0] == "help") {
    var textnode = document.createTextNode("echo    clear    inv    hint");
  }
  else if (element[0] == "inv") {
    var textnode = document.createTextNode("This is your inventory [ " + player.inv + " ]to use item just type it's name to the console.");
  }
  else if (element[0] == "backdoor" && player.stage == 1) {
    backdoor();
    //stage = 2;
  }
  else if (element[0] == "key" && player.stage == 1) {
    var textnode = document.createTextNode("This key doesn't match, but real hecker don't need key, real hecker would find [backdoor].");
  }
  else if (element[0] == "hint") {
    if(player.stage == 1){
    var textnode = document.createTextNode("*HINT*[ these doors look interesting ]*HINT*");
  }
  else if (player.stage == 2) {
    var textnode = document.createTextNode("*HINT*[ use brute force ]*HINT*");
  }
  else if (player.stage == 3) {
    var textnode = document.createTextNode("*HINT*[ ROT13 ]*HINT*");
  }
  else if (player.stage == 4) {
    var textnode = document.createTextNode("*HINT*[ Oh, it's cold here ]*HINT*");
  }
  else if (player.stage == 5) {
    var textnode = document.createTextNode("*HINT*[ Secret of a thieves' den ]*HINT*");
  }
  else if (player.stage == 6) {
    var textnode = document.createTextNode("*HINT*[ Every item is for purpose ]*HINT*");
  }
  else {
    var textnode = document.createTextNode("*HINT[ Try harder ]HINT*");
  }
  }
  else if (element[0] == "computer") {
    var textnode = document.createTextNode("You are already using it.");
  }
  else if (element[0] == 'key' && wall[12].showed == true) {
    var textnode = document.createTextNode("It works. Now deliver hyperdrive module to the vehicle!");
    wall[10].width = 492;
    player.stage = 7;
  }
  else if (element[0] == "camera" && player.inv.includes('camera')) {
    var textnode = document.createTextNode("Oh, look there is hidden message: 'Ali Baba and the Forty Thieves'");
  }
  else if ((element[0] == 'open' || element[0] == 'Open') && (element[1] == 'sesame' || element[1] == 'Sesame') && player.inv.includes('camera') && player.stage == 5) {
    var textnode = document.createTextNode("Look it worked!");
    player.stage = 6;
    thing[5].visible = 1;
    wall[10].width = 492;
  }
  else if (element[0] == "hoodie" && player.inv.includes('hoodie')) {
    if(player.stage == 4){
      var textnode = document.createTextNode("Nice idea, they won't see me If wear a hoodie.");
      player.img = playerimgh;
      wall[8].walk = 1;
      wall[9].msg = 'none';
      player.stage = 5;
    }
    else {
    var textnode = document.createTextNode("You don't need hoodie, it's hot here.");
    }
  }
  else if (element[0] == "whiterabbit" && wall[9].showed == true) {
    player.stage = 4;
  }
  else if (element[0] == "white-paper" && player.inv.includes('white-paper')) {
    var textnode = document.createTextNode("juvgrenoovg");
  }
  else if (element[0] == "hammer" && player.inv.includes('hammer') && wall[7].msg != "It's broken!" ) {
    if(wall[7].showed == true) {
      player.x = 20;
      player.y = 700;
      player.stage = 3;
      var textnode = document.createTextNode("SEGMENTATION FAULT");
      wall[7].color = '#435448';
      wall[7].msg = "It's broken!";
    }
    else {
      var textnode = document.createTextNode("It's a great tool for brute force, but in this case there is another way.");
    }
  }
  else
  {
    var textnode = document.createTextNode('command not found');
  }

  return textnode;
}

var input = document.getElementById("console");
var output = document.getElementById("output");
var box = document.getElementById("container");
var node = document.createElement("LI");

input.addEventListener('keypress', function(e){
  if (e.key === 'Enter') {

    var x = document.getElementById("console").value;
    var node = document.createElement("LI");
    var span = document.createElement('span');
    var br = document.createElement("br");

    if(start){
      name = x;
      if(name != '') {
      start = false;
      message1();
      }
      else {
        clear();
        hint("Really? Try again")
      }
      return 0;
    }

    var command = document.createTextNode(":~# " + x);

    span.style.color = 'green';

    span.appendChild(document.createTextNode('root@hecker'));
    node.appendChild(span);
    node.appendChild(command);
    node.appendChild(br);

    var element = x.split(" ");

    if(element[0]!="clear") {
      var textnode = check(element);
    }
    else {
      while (output.hasChildNodes()) {
        output.removeChild(output.firstChild);
      }
    }

    document.getElementById("console").value = '';
    if(textnode != undefined){
      node.appendChild(textnode);
      output.appendChild(node);
      box.scrollTop = box.scrollHeight;
    }
  }
});

box.addEventListener('click', function(){
  input.select();
});

function backdoor(){

hint("Push random buttons to execute ..");
br();

const input = document.getElementById("console");
const tense = "H.A.C.K.I.N.G . I.N . P.R.O.C.E.S.S . . . ACCESS GRANTED!";
const tenseArray = tense.slice(" ");
let i = 0;

input.addEventListener("input", function handler() {
  if (i < tenseArray.length) {
    output.append(tenseArray[i]);
  }
  input.value = "";
  i++;
  if(i>= tenseArray.length){
    if(player.stage<2){player.stage = 2;}
    this.removeEventListener('input', handler);
    br();
  }
});
}

function hint(text){
  let msg = document.createTextNode(text);
  document.getElementById("console").value = '';
  output.appendChild(msg);
  box.scrollTop = box.scrollHeight;
}

function br(){
  var br = document.createElement("br");
  output.appendChild(br);
  box.scrollTop = box.scrollHeight;
}

function clear(){
  while (output.hasChildNodes()) {
    output.removeChild(output.firstChild);
  }
}

function message1(){
  clear();
  creepyWrite("Wake up, " + name + "...", 100);
  setTimeout(function(){
    clear();
    creepyWrite("We need to fix the damn hyperdrive. Let's explore this station maybe we will find something. If you need [help] just type it here.", 50)
  }, 3000);
  setTimeout(function(){
    creepyWrite("Knock, knock, knock " + name + ".", 50)
  }, 13000);
}

var i = 0;
var txt;
var ar = [];
var speed = 100;
function creepyWrite(text, spd){
  i = 0;
  speed = spd;
  txt = text;
  ar = txt.split('');
  loop();
}
function loop() {
   setTimeout(function () {
      hint(ar[i]);
      i++;
      if (i < ar.length) {
         loop();
      }
      else {
        br();
      }
   }, speed)
}

function end(){
  clear();
  hint("Great job. mr. "+ name +" you saved our asses, thank you.");
}
